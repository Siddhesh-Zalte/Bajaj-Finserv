def run(path) :     
    # import modules here 
    import pandas as pd 

    # logic 
    df = pd.read_excel(path)
    
    # return your output
    return df